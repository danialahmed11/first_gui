import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class MyAppp extends StatelessWidget {
  const MyAppp({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          leading: const Icon(
            Icons.more_horiz_outlined,
            color: Colors.black,
          ),
          title: const Text(
            "Stylish",
            style: TextStyle(color: Color.fromARGB(255, 13, 100, 170)),
          ),
          actions: const [
            Padding(
              padding: EdgeInsets.all(5),
              child: CircleAvatar(
                backgroundImage: NetworkImage(
                    "https://cdn.pixabay.com/photo/2016/11/18/23/38/child-1837375_960_720.png"),
                radius: 20,
              ),
            )
          ],
          centerTitle: true,
          backgroundColor: Colors.white,
        ),
        body: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(children: [
              const Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Column(
                    children: [
                      SizedBox(
                        height: 10,
                      ),
                      CircleAvatar(
                        radius: 25,
                        backgroundImage: NetworkImage(
                            "https://cdn.pixabay.com/photo/2016/04/29/21/14/woman-1361904_960_720.jpg"),
                      ),
                      SizedBox(height: 10),
                      Text('Beauty'),
                    ],
                  ),
                  SizedBox(width: 20),
                  Column(
                    children: [
                      SizedBox(
                        height: 10,
                      ),
                      CircleAvatar(
                        radius: 25,
                        backgroundImage: NetworkImage(
                            "https://cdn.pixabay.com/photo/2021/08/22/15/39/kid-6565461_960_720.jpg"),
                      ),
                      SizedBox(height: 10),
                      Text('Faishon'),
                    ],
                  ),
                  SizedBox(width: 20),
                  Column(
                    children: [
                      SizedBox(
                        height: 10,
                      ),
                      CircleAvatar(
                        radius: 25,
                        backgroundImage: NetworkImage(
                            "https://cdn.pixabay.com/photo/2018/10/09/03/23/mitten-3734000_960_720.jpg"),
                      ),
                      SizedBox(height: 10),
                      Text('Kids'),
                    ],
                  ),
                  SizedBox(width: 20),
                  Column(
                    children: [
                      SizedBox(
                        height: 10,
                      ),
                      CircleAvatar(
                        radius: 25,
                        backgroundImage: NetworkImage(
                            "https://media.istockphoto.com/id/1488453249/photo/make-up-table.jpg?s=1024x1024&w=is&k=20&c=F50rBkoTDpq1-a7pATxuaryM1YoHH1N2ZHCjpityKsw="),
                      ),
                      SizedBox(height: 10),
                      Text('Mens'),
                    ],
                  ),
                ],
              ),
              const SizedBox(height: 20),
              Container(
                width: 500,
                height: 200,
                decoration: BoxDecoration(
                  color: Color.fromARGB(255, 255, 26, 26),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: const Padding(
                  padding: EdgeInsets.all(10),
                  child: Column(children: [
                    SizedBox(
                      height: 10,
                    ),
                    Text(
                      "50-40% OFF",
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 20,
                          fontWeight: FontWeight.w800),
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    Text(
                      "Now in (Product)",
                      style: TextStyle(color: Colors.white),
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    Text(
                      "All Colors",
                      style: TextStyle(color: Colors.white),
                    ),
                    SizedBox(
                      height: 15,
                    ),
                    Padding(
                      padding: EdgeInsets.all(1),
                      child: ElevatedButton(
                        onPressed: null,
                        child: Text(
                          "Shop Now",
                          style: TextStyle(color: Colors.white),
                        ),
                        style: ButtonStyle(
                            side: MaterialStatePropertyAll(
                                BorderSide(color: Colors.white))),
                      ),
                    ),
                  ]),
                ),
              ),
              const SizedBox(
                height: 1,
              ),
              Column(
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(20),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  Container(
                    width: 500,
                    height: 70,
                    decoration: BoxDecoration(
                      color: Colors.blue,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: const Padding(
                      padding: EdgeInsets.all(11),
                      child: Row(children: [
                        SizedBox(
                          height: 5,
                        ),
                        Text(
                          "Deal Of The Day\n22h 55m 20s remaining",
                          style: TextStyle(color: Colors.white),
                        ),
                        Padding(
                          padding: EdgeInsets.only(left: 185),
                          child: ElevatedButton(
                            style: ButtonStyle(
                                side: MaterialStatePropertyAll(
                                    BorderSide(color: Colors.white))),
                            onPressed: null,
                            child: Text(
                              "View All",
                              style: TextStyle(color: Colors.white),
                            ),
                          ),
                        )
                      ]),
                    ),
                  ),
                ],
              ),
              Card(
                child: Column(
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(20),
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    Container(
                      width: 500,
                      height: 70,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: const Padding(
                        padding: EdgeInsets.all(11),
                        child: Row(children: [
                          CircleAvatar(
                            backgroundImage: NetworkImage(
                                "https://cdn.pixabay.com/photo/2018/10/09/03/23/mitten-3734000_960_720.jpg"),
                          ),
                          SizedBox(
                            height: 20,
                          ),
                          Padding(
                            padding: EdgeInsets.only(left: 20),
                            child: Text(
                              "Special Offer\n22h 55m 20s remaining",
                              style: TextStyle(color: Colors.black),
                            ),
                          ),
                        ]),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(
                height: 10,
              ),
              Column(
                children: [
                  ClipRRect(
                      borderRadius: BorderRadius.circular(20),
                      child: Image.network(
                        "https://media.istockphoto.com/id/1488453249/photo/make-up-table.jpg?s=1024x1024&w=is&k=20&c=F50rBkoTDpq1-a7pATxuaryM1YoHH1N2ZHCjpityKsw=",
                      )),
                  const SizedBox(
                    height: 20,
                  ),
                  Container(
                    width: 500,
                    height: 70,
                    decoration: BoxDecoration(
                      color: Color.fromARGB(255, 255, 26, 26),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: const Padding(
                      padding: EdgeInsets.all(11),
                      child: Row(children: [
                        SizedBox(
                          height: 5,
                        ),
                        Text(
                          "Trending Products\nLast Date 20/02/2024",
                          style: TextStyle(color: Colors.white),
                        ),
                        Padding(
                          padding: EdgeInsets.only(left: 185),
                          child: ElevatedButton(
                              style: ButtonStyle(
                                  side: MaterialStatePropertyAll(
                                      BorderSide(color: Colors.white))),
                              onPressed: null,
                              child: Text(
                                "View All",
                                style: TextStyle(color: Colors.white),
                              )),
                        )
                      ]),
                    ),
                  ),
                ],
              ),
              const SizedBox(
                height: 10,
              ),
              Column(
                children: [
                  ClipRRect(
                      borderRadius: BorderRadius.circular(20),
                      child: Image.network(
                        "https://media.istockphoto.com/id/1488453249/photo/make-up-table.jpg?s=1024x1024&w=is&k=20&c=F50rBkoTDpq1-a7pATxuaryM1YoHH1N2ZHCjpityKsw=",
                      )),
                  Container(
                    width: 500,
                    height: 70,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: const Padding(
                      padding: EdgeInsets.all(11),
                      child: Row(children: [
                        SizedBox(
                          height: 5,
                        ),
                        Text(
                          "New Arrivals\nSummer' 25 Collections",
                          style: TextStyle(color: Colors.black),
                        ),
                        Padding(
                          padding: EdgeInsets.only(left: 185),
                          child: ElevatedButton(
                              style: ButtonStyle(
                                  backgroundColor:
                                      MaterialStatePropertyAll(Colors.red),
                                  side: MaterialStatePropertyAll(
                                      BorderSide(color: Colors.red))),
                              onPressed: null,
                              child: Text(
                                "View All",
                                style: TextStyle(color: Colors.white),
                              )),
                        )
                      ]),
                    ),
                  ),
                ],
              ),
            ]),
          ),
        ));
  }
}
