import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class MyAppp extends StatelessWidget {
  const MyAppp({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          leading: const Icon(
            Icons.more_horiz_outlined,
            color: Colors.black,
          ),
          title: const Text(
            "UI Practice",
            style: TextStyle(color: Color.fromARGB(255, 13, 100, 170)),
          ),
          actions: const [
            Padding(
              padding: EdgeInsets.all(5),
              child: CircleAvatar(
                backgroundImage: NetworkImage(
                    "https://cdn.pixabay.com/photo/2016/11/18/23/38/child-1837375_960_720.png"),
                radius: 20,
              ),
            )
          ],
          centerTitle: true,
          backgroundColor: Colors.white,
        ),
        body: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(children: [
              const Row(
                children: [
                  Column(
                    children: [
                      SizedBox(
                        height: 10,
                      ),
                      CircleAvatar(
                        radius: 25,
                        backgroundImage: NetworkImage(
                            "https://cdn.pixabay.com/photo/2016/04/29/21/14/woman-1361904_960_720.jpg"),
                      ),
                      SizedBox(height: 10),
                      Text('Beauty'),
                    ],
                  ),
                  SizedBox(width: 20),
                  Column(
                    children: [
                      SizedBox(
                        height: 10,
                      ),
                      CircleAvatar(
                        radius: 25,
                        backgroundImage: NetworkImage(
                            "https://cdn.pixabay.com/photo/2021/08/22/15/39/kid-6565461_960_720.jpg"),
                      ),
                      SizedBox(height: 10),
                      Text('Faishon'),
                    ],
                  ),
                  SizedBox(width: 20),
                  Column(
                    children: [
                      SizedBox(
                        height: 10,
                      ),
                      CircleAvatar(
                        radius: 25,
                        backgroundImage: NetworkImage(
                            "https://cdn.pixabay.com/photo/2018/10/09/03/23/mitten-3734000_960_720.jpg"),
                      ),
                      SizedBox(height: 10),
                      Text('Kids'),
                    ],
                  ),
                  SizedBox(width: 20),
                  Column(
                    children: [
                      SizedBox(
                        height: 10,
                      ),
                      CircleAvatar(
                        radius: 25,
                        backgroundImage: NetworkImage(
                            "https://media.istockphoto.com/id/1488453249/photo/make-up-table.jpg?s=1024x1024&w=is&k=20&c=F50rBkoTDpq1-a7pATxuaryM1YoHH1N2ZHCjpityKsw="),
                      ),
                      SizedBox(height: 10),
                      Text('Mens'),
                    ],
                  ),
                ],
              ),
              const SizedBox(height: 20),
              Container(
                width: 500,
                height: 250,
                decoration: BoxDecoration(
                  color: Color.fromARGB(255, 255, 26, 26),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: const Padding(
                  padding: EdgeInsets.all(10),
                  child: Column(children: [
                    SizedBox(
                      height: 20,
                    ),
                    Text(
                      "UPTO 50% OFF",
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 20,
                          fontWeight: FontWeight.w800),
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    Text(
                      "New Eid Collection Are Now Available On Website",
                      style: TextStyle(color: Colors.white),
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    Text(
                      "SO BUY AND ENJOY THIS AMAZING OFFER",
                      style: TextStyle(color: Colors.white),
                    ),
                    SizedBox(
                      height: 25,
                    ),
                    Padding(
                      padding: EdgeInsets.all(1),
                      child: ElevatedButton(
                        onPressed: null,
                        child: Text(
                          "Shop Now",
                          style: TextStyle(
                              color: Colors
                                  .white), /////////////////////////////////////////////////////////////////////////////////////////////
                        ),
                        style: ButtonStyle(),
                      ),
                    ),
                  ]),
                ),
              ),
              const SizedBox(
                height: 20,
              ),
              Column(
                children: [
                  ClipRRect(
                      borderRadius: BorderRadius.circular(20),
                      child: Image.network(
                        "https://cdn.pixabay.com/photo/2023/06/11/01/24/flowers-8055013_1280.jpg",
                      )),
                  const SizedBox(
                    height: 20,
                  ),
                  Container(
                    width: 500,
                    height: 70,
                    decoration: BoxDecoration(
                      color: Colors.blue,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: const Padding(
                      padding: EdgeInsets.all(11),
                      child: Row(children: [
                        SizedBox(
                          height: 5,
                        ),
                        Text(
                          "Deal Of The Day\n22h 55m 20s remaining",
                          style: TextStyle(color: Colors.white),
                        ),
                        Padding(
                          padding: EdgeInsets.only(left: 185),
                          child: ElevatedButton(
                              onPressed: null, child: Text("View All")),
                        )
                      ]),
                    ),
                  ),
                ],
              ),
              const SizedBox(
                height: 20,
              ),
              Column(
                children: [
                  ClipRRect(
                      borderRadius: BorderRadius.circular(20),
                      child: Image.network(
                        "https://cdn.pixabay.com/photo/2023/06/11/01/24/flowers-8055013_1280.jpg",
                      )),
                  const SizedBox(
                    height: 20,
                  ),
                  Container(
                    width: 500,
                    height: 70,
                    decoration: BoxDecoration(
                      color: Colors.blue,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: const Padding(
                      padding: EdgeInsets.all(11),
                      child: Row(children: [
                        SizedBox(
                          height: 5,
                        ),
                        Text(
                          "Deal Of The Day\n22h 55m 20s remaining",
                          style: TextStyle(color: Colors.white),
                        ),
                        Padding(
                          padding: EdgeInsets.only(left: 185),
                          child: ElevatedButton(
                              onPressed: null, child: Text("View All")),
                        )
                      ]),
                    ),
                  ),
                ],
              )
            ]),
          ),
        ));
  }
}
